import React from "react";
import Estoque from "./components/Estoque.jsx";

export default function App() {
  return (
    <div>
      <Estoque />
    </div>
  );
}
