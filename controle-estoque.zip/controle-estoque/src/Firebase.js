import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyC_Qkg-9pGQKJUieBz_oP6MuXT0DWtBUEA",
  authDomain: "controle-estoque-b02ea.firebaseapp.com",
  projectId: "controle-estoque-b02ea",
  storageBucket: "controle-estoque-b02ea.firebasestorage.app",
  messagingSenderId: "971083799202",
  appId: "1:971083799202:web:0686daeb953f17a75015fb"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);