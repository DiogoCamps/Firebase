import { useState } from "react";
import RecadoForm from "./components/RecadoForm";
import RecadoList from "./components/RecadoList";
import "./index.css";

function App() {
  const [categoriaSelecionada, setCategoriaSelecionada] = useState("todas");

  return (
    <div className="container">
      <h1>Mural de Recados 🧱</h1>
      <RecadoForm />

      <div className="filtro">
        <label>Filtrar por categoria: </label>
        <select
          value={categoriaSelecionada}
          onChange={(e) => setCategoriaSelecionada(e.target.value)}
        >
          <option value="todas">Todas</option>
          <option value="agradecimento">Agradecimento</option>
          <option value="aviso">Aviso</option>
          <option value="apoio">Apoio</option>
          <option value="sugestao">Sugestão</option>
        </select>
      </div>

      <RecadoList categoriaSelecionada={categoriaSelecionada} />
    </div>
  );
}

export default App;
