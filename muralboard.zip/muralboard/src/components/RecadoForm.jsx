import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../FirebaseConfig.js";

export default function RecadoForm() {
  const [autor, setAutor] = useState("");
  const [mensagem, setMensagem] = useState("");
  const [categoria, setCategoria] = useState("aviso");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (autor.trim() === "" || mensagem.trim() === "") {
      alert("Preencha todos os campos!");
      return;
    }

    await addDoc(collection(db, "recados"), {
      autor,
      mensagem,
      categoria,
      timestamp: serverTimestamp(),
    });

    setAutor("");
    setMensagem("");
    setCategoria("aviso");
  };

  return (
    <form onSubmit={handleSubmit} className="recado-form">
      <input
        type="text"
        placeholder="Seu nome..."
        value={autor}
        onChange={(e) => setAutor(e.target.value)}
      />
      <textarea
        placeholder="Escreva seu recado..."
        value={mensagem}
        onChange={(e) => setMensagem(e.target.value)}
      />
      <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
        <option value="aviso">Aviso</option>
        <option value="agradecimento">Agradecimento</option>
        <option value="apoio">Apoio</option>
        <option value="sugestao">Sugestão</option>
      </select>
      <button type="submit">Enviar Recado</button>
    </form>
  );
}
