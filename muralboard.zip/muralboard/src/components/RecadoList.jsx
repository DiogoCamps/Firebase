import { useEffect, useState } from "react";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "../FirebaseConfig.js";
import RecadoItem from "./RecadoItem";

export default function RecadoList({ categoriaSelecionada }) {
  const [recados, setRecados] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "recados"), orderBy("timestamp", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const lista = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setRecados(lista);
    });
    return () => unsubscribe();
  }, []);

  const filtrados =
    categoriaSelecionada === "todas"
      ? recados
      : recados.filter((r) => r.categoria === categoriaSelecionada);

  return (
    <div className="lista-recados">
      {filtrados.length === 0 ? (
        <p>Nenhum recado ainda.</p>
      ) : (
        filtrados.map((r) => <RecadoItem key={r.id} recado={r} />)
      )}
    </div>
  );
}
