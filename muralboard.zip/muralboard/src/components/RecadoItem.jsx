import { useState } from "react";
import { doc, deleteDoc, updateDoc } from "firebase/firestore";
import { db } from "../FirebaseConfig.js";

export default function RecadoItem({ recado }) {
  const [editando, setEditando] = useState(false);
  const [novoTexto, setNovoTexto] = useState(recado.mensagem);

  const handleExcluir = async () => {
    if (confirm("Deseja excluir este recado?")) {
      await deleteDoc(doc(db, "recados", recado.id));
    }
  };

  const handleSalvar = async () => {
    await updateDoc(doc(db, "recados", recado.id), {
      mensagem: novoTexto,
    });
    setEditando(false);
  };

  return (
    <div className={`recado-item categoria-${recado.categoria}`}>
      <p><strong>{recado.autor}</strong> ({recado.categoria})</p>
      
      {editando ? (
        <>
          <textarea
            value={novoTexto}
            onChange={(e) => setNovoTexto(e.target.value)}
          />
          <button onClick={handleSalvar}>Salvar</button>
        </>
      ) : (
        <p>{recado.mensagem}</p>
      )}

      <div className="acoes">
        <button onClick={() => setEditando(!editando)}>
          {editando ? "Cancelar" : "Editar"}
        </button>
        <button onClick={handleExcluir}>Excluir</button>
      </div>
    </div>
  );
}