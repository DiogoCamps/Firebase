import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAjKFdPpd_mgirMdNJ6lCROs4UwfZnK1yk",
  authDomain: "muralboard-6831a.firebaseapp.com",
  projectId: "muralboard-6831a",
  storageBucket: "muralboard-6831a.firebasestorage.app",
  messagingSenderId: "396009895736",
  appId: "1:396009895736:web:8ef68ff996df3ac95273cd",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
