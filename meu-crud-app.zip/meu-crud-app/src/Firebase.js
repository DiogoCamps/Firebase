import { initializeApp } from "firebase/app";
import {getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyBu6OgqMA7EWb42iEewYS0E_S7u5APDyBE",
  authDomain: "meu-crud-app-d708a.firebaseapp.com",
  projectId: "meu-crud-app-d708a",
  storageBucket: "meu-crud-app-d708a.firebasestorage.app",
  messagingSenderId: "983598129673",
  appId: "1:983598129673:web:ad2adef87162ef6b498ed8"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
