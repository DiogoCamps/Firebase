import Crud from "./components/Crud";

function App() {
  return (
    <div>
      <Crud />
    </div>
  );
}

export default App;
